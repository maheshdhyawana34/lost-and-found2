# FindIt — Full-stack Lost & Found

## Features
- Fixed server-backed search by item title, description, location, and category
- Lost / Found and category filters
- Registration and login with hashed passwords and JWT
- Reports stored in MongoDB, not just browser storage
- Report an item after login, contact poster, see your reports and delete your own reports
- Responsive layout

## Requirements
Install Node.js LTS and MongoDB Community Server, or create a MongoDB Atlas database.

## Run on Windows / VS Code
1. Extract the ZIP and open the `lost_found_fullstack` folder in VS Code.
2. Open **Terminal → New Terminal**.
3. Run `npm install`.
4. Copy `.env.example` to a new file named `.env`.
5. For local MongoDB, use these values in `.env`:
   ```
   PORT=3000
   MONGODB_URI=mongodb://127.0.0.1:27017/findit_lost_found
   JWT_SECRET=write_a_long_random_secret_here
   ```
6. Start MongoDB. If installed as a Windows service, it may already be running.
7. Run `npm start`.
8. Open **http://localhost:3000** in Chrome.

Do NOT use Live Server for this version. The Express server serves the website and its API.

If MongoDB fails to connect, make sure the MongoDB service is running or use your Atlas connection string for `MONGODB_URI`. Never publish `.env` or database credentials to GitHub.

Note: This is a student/demo project. The contact field is visible to visitors. JWT is stored in localStorage; for production, add rate limiting, secure HttpOnly cookies, email verification, and stronger privacy controls.
